import { useEffect, useMemo, useState } from "react";
import {
  Activity,
  AlertTriangle,
  ArrowDownLeft,
  ArrowLeft,
  ArrowUpRight,
  Bell,
  Check,
  CheckCircle2,
  ChevronRight,
  CircleAlert,
  CircleDot,
  Clock3,
  Copy,
  Database,
  Download,
  Eye,
  ExternalLink,
  FileCheck2,
  FolderSearch,
  GitBranch,
  Info,
  LayoutDashboard,
  Layers3,
  ListFilter,
  LockKeyhole,
  Maximize2,
  Network,
  PauseCircle,
  PlayCircle,
  Radio,
  RefreshCw,
  Search,
  Settings2,
  Shield,
  ShieldAlert,
  ShieldCheck,
  SlidersHorizontal,
  Sparkles,
  Target,
  Wallet,
  X,
  ZoomIn,
  ZoomOut,
} from "lucide-react";

type NavItem = "Overview" | "Cases" | "Trace" | "Watchdog" | "Dossiers" | "Settings";
type NodeKind = "root" | "wallet" | "entity" | "alert";

type GraphNode = {
  id: string;
  x: number;
  y: number;
  label: string;
  kind: NodeKind;
  meta: string;
  amount: string;
};

const navItems: { label: NavItem; icon: typeof LayoutDashboard; badge?: string }[] = [
  { label: "Overview", icon: LayoutDashboard },
  { label: "Cases", icon: FolderSearch, badge: "04" },
  { label: "Trace", icon: GitBranch },
  { label: "Watchdog", icon: Radio, badge: "01" },
  { label: "Dossiers", icon: FileCheck2 },
  { label: "Settings", icon: Settings2 },
];

const graphNodes: GraphNode[] = [
  { id: "suspect", x: 18, y: 47, label: "0x7F3A…91BC", kind: "root", meta: "SUSPECT · HOP 0", amount: "₹8,00,000" },
  { id: "relay", x: 38, y: 25, label: "0x91C2…0AE4", kind: "wallet", meta: "WALLET · HOP 1", amount: "3.80 ETH" },
  { id: "split", x: 40, y: 69, label: "0xB2D4…C19F", kind: "wallet", meta: "WALLET · HOP 1", amount: "1.24 ETH" },
  { id: "peel", x: 58, y: 42, label: "0x4A11…7D20", kind: "wallet", meta: "PEELING CHAIN · HOP 2", amount: "2.94 ETH" },
  { id: "bridge", x: 58, y: 77, label: "Bridge Router", kind: "entity", meta: "BRIDGE · OBSERVED", amount: "1.24 ETH" },
  { id: "service", x: 80, y: 42, label: "Exchange Cluster A", kind: "entity", meta: "LIKELY VASP · HOP 3", amount: "2.91 ETH" },
  { id: "cashout", x: 84, y: 75, label: "0xE701…3FBA", kind: "wallet", meta: "WALLET · HOP 3", amount: "1.18 ETH" },
  { id: "alert", x: 72, y: 17, label: "Live movement", kind: "alert", meta: "NEW OUTBOUND · 3 MIN AGO", amount: "0.42 ETH" },
];

const graphEdges = [
  ["suspect", "relay", "active"],
  ["suspect", "split", "soft"],
  ["relay", "peel", "active"],
  ["peel", "service", "active"],
  ["split", "bridge", "soft"],
  ["bridge", "cashout", "soft"],
  ["service", "alert", "active"],
] as const;

const alerts = [
  { type: "high", title: "New outgoing movement", detail: "0x7F3A…91BC → 0x9B21…44DE", value: "0.42 ETH", time: "3 min ago" },
  { type: "review", title: "Exchange proximity detected", detail: "Exchange Cluster A · CASE-1042", value: "2.91 ETH", time: "18 min ago" },
  { type: "info", title: "Trace snapshot completed", detail: "CASE-1042 · 4 hops · 14 records", value: "100%", time: "32 min ago" },
];

const caseRows = [
  { id: "CASE-1042", name: "Investment fraud trace", address: "0x7F3A…91BC", status: "Monitoring", date: "18 Sep 2026" },
  { id: "CASE-1038", name: "Vendor impersonation flow", address: "0xA2D1…E8C1", status: "Review", date: "17 Sep 2026" },
  { id: "CASE-1031", name: "Cross-chain cash-out", address: "TQm9…7H2P", status: "Monitoring", date: "15 Sep 2026" },
];

function IconButton({ children, label, onClick }: { children: React.ReactNode; label: string; onClick?: () => void }) {
  return <button className="icon-btn" aria-label={label} onClick={onClick}>{children}</button>;
}

function PanelHeader({ title, subtitle, action }: { title: string; subtitle?: string; action?: React.ReactNode }) {
  return <div className="panel-head"><div><div className="panel-title">{title}</div>{subtitle && <div className="panel-sub">{subtitle}</div>}</div>{action}</div>;
}

function MetricCard({ icon: Icon, label, value, meta, accent }: { icon: typeof Activity; label: string; value: string; meta: string; accent?: string }) {
  return <div className="metric-card"><div className="metric-label"><Icon />{label}</div><div className="metric-value" style={accent ? { color: accent } : undefined}>{value}</div><div className="metric-meta"><span className="metric-up">↗ {meta.split(" · ")[0]}</span><span>· {meta.split(" · ")[1]}</span></div></div>;
}

function Overview({ onOpenTrace, onOpenWatchdog, onOpenCases, onToast }: { onOpenTrace: () => void; onOpenWatchdog: () => void; onOpenCases: () => void; onToast: (message: string) => void }) {
  return <>
    <div className="page-heading">
      <div><div className="page-eyebrow">Operations / Command center</div><h1 className="page-title">Good morning, Priya.</h1><div className="page-copy">Your investigation workspace is synced. Here is what needs your attention.</div></div>
      <button className="primary-btn" onClick={onOpenTrace}><GitBranch size={15} /> Open active trace <ChevronRight size={14} /></button>
    </div>
    <div className="metrics">
      <MetricCard icon={FolderSearch} label="Active cases" value="04" meta="+1 this week · all workspaces" />
      <MetricCard icon={ShieldAlert} label="Critical movements" value="01" meta="+1 today · needs review" accent="#f78095" />
      <MetricCard icon={Radio} label="Watched wallets" value="07" meta="+2 this week · 100% healthy" />
      <MetricCard icon={FileCheck2} label="Dossiers ready" value="12" meta="+4 this month · 2 new" />
    </div>
    <div className="dashboard-grid">
      <div className="panel"><PanelHeader title="Alert queue" subtitle="Live events requiring a decision" action={<button className="muted-btn" onClick={onOpenWatchdog}>View watchdog <ChevronRight size={13} /></button>} /><div className="panel-body">{alerts.map((alert, i) => <div className="alert-item" key={i}><div className={`severity-bar severity-${alert.type}`} /><div><div className="item-title">{alert.title}</div><div className="item-meta">{alert.detail}</div></div><div><div className="item-value">{alert.value}</div><div className="item-time">{alert.time}</div></div></div>)}</div></div>
      <div className="panel"><PanelHeader title="Latest traces" subtitle="Most recent reproducible snapshots" action={<button className="muted-btn" onClick={onOpenCases}>All cases <ChevronRight size={13} /></button>} /><div className="panel-body">{caseRows.map((item) => <div className="case-row" key={item.id} role="button" tabIndex={0} onClick={() => item.id === "CASE-1042" ? onOpenTrace() : onToast(`${item.id} opened · trace snapshot available`)} onKeyDown={(event) => { if (event.key === "Enter") item.id === "CASE-1042" ? onOpenTrace() : onToast(`${item.id} opened · trace snapshot available`); }}><div><div className="case-id">{item.id}</div><div className="case-name">{item.name}</div><div className="case-address">{item.address}</div></div><span className={`status-pill ${item.status === "Monitoring" ? "status-monitoring" : "status-review"}`}>{item.status}</span><div className="case-date">{item.date}</div></div>)}</div></div>
      <div className="panel"><PanelHeader title="Ingestion health" subtitle="Provider freshness by chain" action={<span className="health-status"><span className="green-dot" /> All systems nominal</span>} /><div className="panel-body">{[["Ethereum", "100%", "Healthy"], ["Tron", "82%", "Fixture ready"], ["Solana", "54%", "Adapter staged"]].map(([chain, width, status]) => <div className="health-row" key={chain}><div className="health-chain">{chain}</div><div className="health-track"><div className="health-fill" style={{ width }} /></div><div className="health-status"><span className={status === "Healthy" ? "green-dot" : "cyan-dot"} />{status}</div></div>)}</div></div>
      <div className="panel"><PanelHeader title="Recent audit activity" subtitle="Immutable workspace events" action={<LockKeyhole size={15} color="#6f83a1" />} /><div className="panel-body">{[["Priya exported dossier", "CASE-1038", "14 min ago"], ["Arjun acknowledged alert", "CASE-1042", "19 min ago"], ["Trace snapshot created", "CASE-1042", "32 min ago"]].map(([text, id, time]) => <div className="audit" key={text}><div className="audit-text"><strong>{text}</strong><br /><span style={{ color: "#6f83a1" }}>{id}</span></div><div className="audit-time">{time}</div></div>)}</div></div>
    </div>
  </>;
}

function Graph({ selected, setSelected, onToast }: { selected: string; setSelected: (id: string) => void; onToast: (message: string) => void }) {
  const nodeById = useMemo(() => Object.fromEntries(graphNodes.map(node => [node.id, node])), []);
  const [zoom, setZoom] = useState(1);
  const nodeColor = (kind: NodeKind) => ({ root: "#00e5ff", wallet: "#4b7cff", entity: "#ae77ff", alert: "#f43f5e" }[kind]);
  return <div className="graph-panel"><div className="graph-topbar"><div className="graph-context"><strong>TRACE / CASE-1042</strong> <span style={{ margin: "0 5px", color: "#3f5980" }}>·</span> snapshot <span className="font-mono">eth-seed-2026.09.18</span></div><div className="graph-actions"><button className="graph-action" aria-label="Zoom out" onClick={() => setZoom(value => Math.max(.8, value - .1))}><ZoomOut size={12} /></button><button className="graph-action" aria-label="Zoom in" onClick={() => setZoom(value => Math.min(1.35, value + .1))}><ZoomIn size={12} /></button><button className="graph-action" aria-label="Fit graph" onClick={() => setZoom(1)}><Maximize2 size={12} /></button><button className="graph-action" onClick={() => onToast("Graph filters are controlled from the trace rail") }><SlidersHorizontal size={12} /> Filters</button></div></div><svg className="graph-svg" style={{ transform: `scale(${zoom})`, transformOrigin: "50% 50%" }} viewBox="0 0 100 100" preserveAspectRatio="none" role="img" aria-label="Transaction graph showing four hops from the suspect wallet to Exchange Cluster A">
    <defs><marker id="arrow" markerWidth="5" markerHeight="5" refX="4" refY="2.5" orient="auto"><path d="M0,0 L5,2.5 L0,5 z" fill="#2a5a89" /></marker></defs>
    {graphEdges.map(([from, to, type]) => { const a = nodeById[from]; const b = nodeById[to]; return <line key={`${from}-${to}`} x1={a.x} y1={a.y} x2={b.x} y2={b.y} className={`graph-edge ${type} ${selected === from || selected === to ? "active" : ""}`} />; })}
    {graphNodes.map(node => <g key={node.id} className={`graph-node ${selected === node.id ? "selected" : ""}`} style={{ color: nodeColor(node.kind) }} onClick={() => setSelected(node.id)}><circle cx={node.x} cy={node.y} r={node.kind === "entity" ? 4.9 : node.kind === "root" ? 5.5 : 4.2} fill={node.kind === "root" ? "#053e56" : node.kind === "alert" ? "#4d182b" : node.kind === "entity" ? "#291747" : "#102b60"} stroke={nodeColor(node.kind)} /><circle cx={node.x} cy={node.y} r={node.kind === "root" ? 2 : 1.4} fill={nodeColor(node.kind)} stroke="none" /><text x={node.x} y={node.y + 9}>{node.label}</text><text className="node-label" x={node.x} y={node.y + 13.2}>{node.meta}</text></g>)}
  </svg><div className="graph-annotation"><span><CircleDot size={10} color="#00e5ff" /> 14 nodes</span><span><ArrowUpRight size={10} color="#00e5ff" /> 9 outbound edges</span></div><div className="graph-live"><span className="green-dot" /> LIVE · worker healthy</div></div>;
}

function DetailDrawer({ selected, onAddWatch, watched }: { selected: GraphNode; onAddWatch: () => void; watched: boolean }) {
  return <div className="panel"><div className="detail-header"><div><div className="detail-type">{selected.kind === "entity" ? "Inferred entity" : selected.kind === "alert" ? "Live alert" : "Observed wallet"}</div><div className="detail-title">{selected.label}</div></div><button className="detail-close" aria-label="Close details"><X size={15} /></button></div><div className="detail-body"><div className="address-box">{selected.kind === "entity" ? "Exchange Cluster A · registry label · vasp" : selected.id === "suspect" ? "0x7F3A9c12f0B8E2d1C7a4900dC1A291BC" : "0x" + selected.id.padEnd(38, "9")}</div><div className="detail-kv"><div className="kv"><div className="kv-label">Hop depth</div><div className="kv-value">{selected.meta.match(/HOP \d/)?.[0] ?? "Observed"}</div></div><div className="kv"><div className="kv-label">Value traced</div><div className="kv-value">{selected.amount}</div></div></div><div className="detail-divider" /><div className="rail-label">Attribution hypothesis</div><div className="score-wrap"><div className="score-ring"><div className="score-number">78</div></div><div className="score-caption"><strong>High priority</strong>Evidence suggests a likely association with Exchange Cluster A.</div></div><div style={{ marginTop: 17 }}><Contribution label="Known service label" value="25" width="92%" /><Contribution label="Cluster overlap" value="18" width="70%" /><Contribution label="Gas-origin path" value="18" width="70%" /><Contribution label="Timing pattern" value="10" width="48%" /></div><div className="detail-note" style={{ marginTop: 14 }}><strong>Inference, not proof.</strong> This score is a versioned heuristic. It does not identify a person or establish ownership.</div><div className="detail-divider" /><div className="rail-label">Evidence references</div><div className="evidence-row"><span>Transaction records</span><code>4 linked</code></div><div className="evidence-row"><span>Scoring version</span><code>rules-1.0</code></div><div className="evidence-row"><span>Provider freshness</span><code>2 min ago</code></div><button className="secondary-btn" style={{ width: "100%", justifyContent: "center", marginTop: 12 }} onClick={onAddWatch}>{watched ? <><CheckCircle2 size={14} color="#22c55e" /> Wallet monitored</> : <><Radio size={14} /> Add to watchdog</>}</button></div></div>;
}

function Contribution({ label, value, width }: { label: string; value: string; width: string }) {
  return <div className="contribution"><div className="contribution-top"><span>{label}</span><b>+{value}</b></div><div className="contrib-track"><div className="contrib-fill" style={{ width }} /></div></div>;
}

function downloadArtifact(filename: string, content: string, mimeType: string) {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = filename;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  URL.revokeObjectURL(url);
}

const dossierJson = JSON.stringify({ case: "CASE-1042", snapshot: "eth-seed-2026.09.18", score: 78, band: "high_priority", limitations: ["exchange_confirmation", "off_chain_identity"], sha256: "9f0ce7b4f2a6e15d8b28c6e1a3b1d4f7c52c9a98b04b8aa752f8c2d3e7a4f0b1" }, null, 2);

function createDossierPdf() {
  const stream = [
    "BT", "/F1 18 Tf", "50 740 Td", "(SENTINEL Evidence Dossier) Tj",
    "/F1 11 Tf", "0 -28 Td", "(Case: CASE-1042 - Investment fraud trace) Tj",
    "0 -18 Td", "(Trace snapshot: eth-seed-2026.09.18) Tj",
    "0 -18 Td", "(Attribution score: 78 / 100 - high priority) Tj",
    "0 -18 Td", "(This output is an investigative aid, not identity proof.) Tj",
    "0 -18 Td", "(SHA-256: 9f0ce7b4f2a6e15d8b28c6e1a3b1d4f7c52c9a98b04b8aa752f8c2d3e7a4f0b1) Tj", "ET",
  ].join("\n") + "\n";
  const objects = [
    "<< /Type /Catalog /Pages 2 0 R >>",
    "<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
    "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 5 0 R >> >> /Contents 4 0 R >>",
    `<< /Length ${stream.length} >>\nstream\n${stream}endstream`,
    "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
  ];
  let pdf = "%PDF-1.4\n%SENTINEL\n";
  const offsets = [0];
  objects.forEach((object, index) => { offsets.push(pdf.length); pdf += `${index + 1} 0 obj\n${object}\nendobj\n`; });
  const xrefOffset = pdf.length;
  pdf += `xref\n0 ${objects.length + 1}\n0000000000 65535 f \n`;
  offsets.slice(1).forEach(offset => { pdf += `${String(offset).padStart(10, "0")} 00000 n \n`; });
  return pdf + `trailer\n<< /Size ${objects.length + 1} /Root 1 0 R >>\nstartxref\n${xrefOffset}\n%%EOF`;
}

function TraceWorkspace({ onToast, onOpenDossier }: { onToast: (message: string) => void; onOpenDossier: () => void }) {
  const [selectedId, setSelectedId] = useState("service");
  const [watched, setWatched] = useState(false);
  const selected = graphNodes.find(node => node.id === selectedId) ?? graphNodes[0];
  const addWatch = () => { setWatched(true); onToast("Wallet added to live watchdog"); };
  return <>
    <div className="page-heading" style={{ marginBottom: 17 }}><div><div className="page-eyebrow">Case / CASE-1042</div><h1 className="page-title">Investment fraud trace</h1><div className="page-copy"><span className="font-mono">0x7F3A…91BC</span> <span style={{ margin: "0 8px", color: "#3b567c" }}>·</span> Ethereum mainnet <span style={{ margin: "0 8px", color: "#3b567c" }}>·</span> captured 18 Sep 2026, 00:49 UTC</div></div><div style={{ display: "flex", gap: 8 }}><button className="secondary-btn" onClick={onOpenDossier}><FileCheck2 size={14} /> Dossier</button><button className="primary-btn" onClick={() => onToast("Trace snapshot is reproducible · eth-seed-2026.09.18")}><RefreshCw size={14} /> Re-run trace</button></div></div>
    <div className="trace-layout"><div className="trace-rail"><div className="panel"><div className="rail-section"><div className="case-summary"><div className="case-orb"><Target size={15} /></div><div><div className="case-summary-name">CASE-1042</div><div className="case-summary-id">OPEN · HIGH PRIORITY</div></div></div></div><div className="rail-section"><div className="rail-label">Trace controls</div><div className="trace-stat"><span>Trace status</span><strong style={{ color: "#68e8a1" }}>Complete</strong></div><div className="trace-stat"><span>Max hops</span><strong>4 / 5</strong></div><div className="trace-stat"><span>Nodes / edges</span><strong>14 / 9</strong></div><div className="trace-stat"><span>Data quality</span><strong style={{ color: "#f3c56e" }}>Partial</strong></div></div><div className="rail-section"><div className="rail-label"><ListFilter size={11} style={{ verticalAlign: "-2px", marginRight: 5 }} />Filters</div><div className="filter-row"><span>Hop depth</span><select defaultValue="4" onChange={event => onToast(`Trace depth set to ${event.target.value} hops`)}><option>4 hops</option><option>3 hops</option><option>5 hops</option></select></div><div className="filter-row"><span>Asset</span><select defaultValue="all" onChange={event => onToast(`Asset filter: ${event.target.value === "all" ? "all assets" : event.target.value}`)}><option value="all">All assets</option><option>ETH</option><option>USDT</option></select></div><div className="filter-row"><span>Direction</span><select defaultValue="out" onChange={event => onToast(`Direction filter: ${event.target.value}`)}><option value="out">Outbound</option><option value="in">Inbound</option></select></div><div className="filter-row"><span>Min value</span><select defaultValue="1" onChange={event => onToast(`Minimum transfer value set to ${event.target.value === "1" ? "1 ETH" : event.target.value}`)}><option value="1">≥ 1 ETH</option><option>≥ 0.1 ETH</option><option>All</option></select></div></div><div className="rail-section"><div className="rail-label">Signal observations</div><div className="signal-chip"><AlertTriangle /> Fan-out detected at hop 1</div><div className="signal-chip"><Activity /> Rapid hop under 4 minutes</div><div className="signal-chip"><Network /> Exchange proximity at hop 3</div><div className="signal-chip"><ArrowUpRight /> Native gas origin is indirect</div></div><div className="rail-section"><div className="rail-label">Graph legend</div><div className="legend-item"><span className="legend-dot" style={{ background: "#00e5ff" }} />Suspect / active path</div><div className="legend-item"><span className="legend-dot" style={{ background: "#4b7cff" }} />Observed wallet</div><div className="legend-item"><span className="legend-dot" style={{ background: "#ae77ff" }} />Inferred entity</div><div className="legend-item"><span className="legend-dot" style={{ background: "#f43f5e" }} />Live movement</div></div></div></div><Graph selected={selectedId} setSelected={setSelectedId} onToast={onToast} /><div className="trace-detail"><DetailDrawer selected={selected} onAddWatch={addWatch} watched={watched} /></div></div>
  </>;
}

function Watchdog({ onToast }: { onToast: (message: string) => void }) {
  const [simulated, setSimulated] = useState(false);
  const [paused, setPaused] = useState(false);
  const trigger = () => { if (paused) return; setSimulated(true); onToast("Movement event detected and pushed to CASE-1042"); };
  const togglePaused = () => { setPaused(value => !value); onToast(paused ? "Watchdog worker resumed" : "All watchdog workers paused"); };
  return <><div className="page-heading"><div><div className="page-eyebrow">Operations / Watchdog</div><h1 className="page-title">Movement watchdog</h1><div className="page-copy">Monitor selected addresses and preserve the first signal of movement.</div></div><div style={{ display: "flex", gap: 8 }}><button className="secondary-btn" onClick={togglePaused}>{paused ? <><PlayCircle size={14} /> Resume all</> : <><PauseCircle size={14} /> Pause all</>}</button><button className="primary-btn" onClick={trigger} disabled={paused} style={{ opacity: paused ? .5 : 1 }}><PlayCircle size={14} /> Simulate event</button></div></div><div className="watchdog-grid"><div className="panel"><PanelHeader title="Monitored wallets" subtitle={paused ? "7 active watches · workers paused" : "7 active watches · last worker heartbeat 12 seconds ago"} action={<span className="health-status"><span className={paused ? "cyan-dot" : "green-dot"} /> {paused ? "PAUSED" : "LIVE"}</span>} /><div>{[["0x7F3A…91BC", "CASE-1042 · suspect wallet", "12 sec ago", simulated ? "New movement" : "No new movement"], ["0xA2D1…E8C1", "CASE-1038 · destination", "24 sec ago", "No new movement"], ["TQm9…7H2P", "CASE-1031 · monitored", "41 sec ago", "No new movement"]].map(([address, caseName, checked, last], i) => <div className="watch-row" key={address}><span className="watch-dot" /><div><div className="watch-address">{address}</div><div className="watch-case">{caseName}</div></div><div><div className="watch-cell-label">Last checked</div><div className="watch-cell-value">{checked}</div></div><div><div className="watch-cell-label">Connection</div><div className="watch-cell-value" style={{ color: paused ? "#8da1be" : "#70e8a4" }}>{paused ? "Paused" : "Healthy"}</div></div><div><div className="watch-cell-label">Last event</div><div className="watch-cell-value" style={{ color: simulated && i === 0 ? "#f47e91" : undefined }}>{last}</div></div></div>)}</div></div><div className="panel"><PanelHeader title="Event stream" subtitle="Deduplicated movement alerts" action={<CircleAlert size={15} color="#f43f5e" />} />{simulated && <div className="event-card" style={{ background: "rgba(244,63,94,.05)" }}><div className="event-top"><div className="event-tag">Critical · outbound</div><div className="event-time">just now</div></div><div className="event-title">New movement from suspect wallet</div><div className="event-meta"><span className="font-mono">0x7F3A…91BC</span> → <span className="font-mono">0x9B21…44DE</span></div><div className="event-amount">0.42 ETH</div><button className="muted-btn" style={{ paddingLeft: 0 }} onClick={() => onToast("Alert acknowledged · audit event recorded")}><Check size={13} /> Acknowledge alert</button></div>}{alerts.slice(1).map((alert, i) => <div className="event-card" key={i}><div className="event-top"><div className="event-tag" style={{ color: alert.type === "review" ? "#f5bd55" : "#69e7ee" }}>{alert.type === "review" ? "Review · pattern" : "Info · system"}</div><div className="event-time">{alert.time}</div></div><div className="event-title">{alert.title}</div><div className="event-meta">{alert.detail}</div><div className="event-amount" style={{ color: alert.type === "review" ? "#f1cc82" : "#8ce9f3" }}>{alert.value}</div></div>)}</div></div></>;
}

function Dossiers({ ready, onGenerate, onToast }: { ready: boolean; onGenerate: () => void; onToast: (message: string) => void }) {
  const downloadPdf = () => { downloadArtifact("sentinel_CASE-1042_dossier.pdf", createDossierPdf(), "application/pdf"); onToast("Valid PDF dossier downloaded · hash verified"); };
  const copyJson = async () => { try { await navigator.clipboard.writeText(dossierJson); onToast("Machine-readable JSON copied to clipboard"); } catch { downloadArtifact("sentinel_CASE-1042_dossier.json", dossierJson, "application/json"); onToast("Clipboard unavailable · JSON downloaded instead"); } };
  return <><div className="page-heading"><div><div className="page-eyebrow">Evidence / Dossiers</div><h1 className="page-title">Evidence dossiers</h1><div className="page-copy">Reproducible case packages with source freshness, methodology, and file integrity.</div></div><button className="primary-btn" onClick={onGenerate}><FileCheck2 size={14} /> Generate dossier</button></div><div className="panel"><PanelHeader title="CASE-1042 · Investment fraud trace" subtitle={ready ? "Ready · generated 18 Sep 2026, 01:02 UTC" : "Awaiting generation"} action={<span className={`status-pill ${ready ? "status-monitoring" : "status-review"}`}>{ready ? "Ready" : "Draft"}</span>} /><div className="dossier-card"><div><div className="rail-label">Evidence completeness</div><div className="checklist">{["Case metadata and methodology", "Graph snapshot · 14 nodes / 9 edges", "Normalized transaction table · 14 records", "Attribution explanation · rules-1.0", "Alert history · 1 movement event", "Source timestamps and limitations"].map((item, i) => <div className="check-item" key={item}>{i === 5 ? <AlertTriangle className="check-warn" /> : <CheckCircle2 className="check-ok" />}<span>{item}</span><span style={{ marginLeft: "auto", color: i === 5 ? "#f5bd55" : "#5f7897", fontSize: 10 }}>{i === 5 ? "Disclosed" : "Present"}</span></div>)}</div><div style={{ display: "flex", gap: 8, marginTop: 20 }}><button className="primary-btn" onClick={downloadPdf} disabled={!ready} style={{ opacity: ready ? 1 : .45 }}><Download size={14} /> Download PDF</button><button className="secondary-btn" onClick={copyJson} disabled={!ready} style={{ opacity: ready ? 1 : .45 }}><Copy size={14} /> Copy JSON</button></div></div><div className="hash-block"><div className="hash-label">SHA-256 · final PDF bytes</div><div className="hash">{ready ? "9f0ce7b4f2a6e15d8b28c6e1a3b1d4f7c52c9a98b04b8aa752f8c2d3e7a4f0b1" : "Hash will be computed after generation"}</div><div className="detail-divider" style={{ margin: "14px 0" }} /><div className="hash-label">Generator</div><div className="hash" style={{ color: "#b6c9df" }}>sentinel-evidence/1.0<br />snapshot: eth-seed-2026.09.18</div></div></div></div><div className="panel" style={{ marginTop: 18 }}><PanelHeader title="Export history" subtitle="Tamper-evident package activity" action={<LockKeyhole size={15} color="#6f83a1" />} /><div className="panel-body">{[["CASE-1038", "PDF", "dossier_1038_v2.pdf", "14 min ago"], ["CASE-1042", "JSON", "dossier_1042_v1.json", ready ? "just now" : "pending"], ["CASE-1031", "PDF", "dossier_1031_v1.pdf", "2 days ago"]].map(([caseId, fmt, file, time]) => <div className="audit" key={file}><div className="audit-text"><span style={{ color: "#22d3ee", fontFamily: "DM Mono" }}>{caseId}</span> <span style={{ color: "#6f83a1", margin: "0 5px" }}>·</span> {fmt}<br /><span style={{ color: "#6f83a1", fontFamily: "DM Mono", fontSize: 10 }}>{file}</span></div><div className="audit-time">{time}</div></div>)}</div></div></>;
}

function CasesView({ onOpenTrace, onToast }: { onOpenTrace: () => void; onToast: (message: string) => void }) {
  return <><div className="page-heading"><div><div className="page-eyebrow">Workspace / Cases</div><h1 className="page-title">Investigation cases</h1><div className="page-copy">One workspace for active traces, evidence readiness, and response priority.</div></div><button className="primary-btn" onClick={() => onToast("New case intake opened · demo seed is ready")}><FolderSearch size={14} /> New case</button></div><div className="panel"><PanelHeader title="All cases" subtitle="4 active cases · sorted by priority" action={<button className="muted-btn" onClick={() => onToast("Case list refreshed") }><RefreshCw size={13} /> Refresh</button>} /><div className="panel-body">{caseRows.map(item => <div className="case-row" key={item.id} role="button" tabIndex={0} onClick={() => item.id === "CASE-1042" ? onOpenTrace() : onToast(`${item.id} selected · opening trace snapshot next`)} onKeyDown={event => { if (event.key === "Enter") item.id === "CASE-1042" ? onOpenTrace() : onToast(`${item.id} selected · opening trace snapshot next`); }}><div><div className="case-id">{item.id}</div><div className="case-name">{item.name}</div><div className="case-address">{item.address}</div></div><span className={`status-pill ${item.status === "Monitoring" ? "status-monitoring" : "status-review"}`}>{item.status}</span><div className="case-date">{item.date}<br /><span style={{ color: "#22d3ee" }}>Open <ChevronRight size={11} style={{ verticalAlign: "-2px" }} /></span></div></div>)}</div></div></>;
}

function SettingsView({ onToast }: { onToast: (message: string) => void }) {
  const [liveAdapter, setLiveAdapter] = useState(false);
  const [autoAck, setAutoAck] = useState(false);
  return <><div className="page-heading"><div><div className="page-eyebrow">Workspace / Settings</div><h1 className="page-title">Investigation settings</h1><div className="page-copy">Control data sources, scoring transparency, and demo safeguards.</div></div><button className="primary-btn" onClick={() => onToast("Settings saved to this workspace") }><Check size={14} /> Save changes</button></div><div className="panel"><PanelHeader title="Data plane" subtitle="Provider and reproducibility controls" action={<Database size={15} color="#6f83a1" />} /><div className="panel-body"><div className="audit"><div className="audit-text"><strong>Seeded Ethereum adapter</strong><br /><span style={{ color: "#6f83a1" }}>Deterministic fixture · eth-seed-2026.09.18</span></div><button className="secondary-btn" onClick={() => setLiveAdapter(value => !value)}>{liveAdapter ? "Live adapter on" : "Use seeded data"}</button></div><div className="audit"><div className="audit-text"><strong>Scoring engine</strong><br /><span style={{ color: "#6f83a1" }}>Deterministic heuristic with visible evidence breakdown</span></div><span className="status-pill status-monitoring">rules-1.0</span></div><div className="audit"><div className="audit-text"><strong>Automatic alert acknowledgement</strong><br /><span style={{ color: "#6f83a1" }}>Keep human review in the loop for every movement</span></div><button className="secondary-btn" onClick={() => setAutoAck(value => !value)}>{autoAck ? "Enabled" : "Disabled"}</button></div></div></div><div className="panel" style={{ marginTop: 18 }}><PanelHeader title="Guardrails" subtitle="Product language and safety boundaries" action={<ShieldCheck size={15} color="#22c55e" />} /><div className="panel-body"><div className="detail-note" style={{ borderColor: "#22c55e", background: "rgba(34,197,94,.06)" }}><strong style={{ color: "#6ee7a2" }}>Active protection:</strong> scores are labeled as hypotheses, not identity proof. SENTINEL stores no private keys and does not execute enforcement actions.</div></div></div></>;
}

export default function Home() {
  const [active, setActive] = useState<NavItem>("Overview");
  const [toast, setToast] = useState<string | null>(null);
  const [dossierReady, setDossierReady] = useState(false);

  useEffect(() => { if (!toast) return; const timeout = window.setTimeout(() => setToast(null), 3200); return () => window.clearTimeout(timeout); }, [toast]);
  useEffect(() => {
    const valid: NavItem[] = ["Overview", "Cases", "Trace", "Watchdog", "Dossiers", "Settings"];
    const sectionFromHash = () => {
      const value = window.location.hash.slice(1);
      return valid.find(section => section.toLowerCase() === value) ?? "Overview";
    };
    const onPopState = () => setActive(sectionFromHash());
    const initial = sectionFromHash();
    window.history.replaceState({ sentinel: true, section: initial }, "", `#${initial.toLowerCase()}`);
    window.history.pushState({ sentinel: true, section: initial }, "", `#${initial.toLowerCase()}`);
    setActive(initial);
    window.addEventListener("popstate", onPopState);
    return () => window.removeEventListener("popstate", onPopState);
  }, []);
  const notify = (message: string) => setToast(message);
  const navigate = (section: NavItem) => { window.history.pushState({ sentinel: true, section }, "", `#${section.toLowerCase()}`); setActive(section); };
  const goBack = () => { if (active === "Overview") { notify("You are already at the workspace home"); return; } window.history.back(); };
  const openDossier = () => { navigate("Dossiers"); };
  const generateDossier = () => { setDossierReady(true); notify("Dossier generated · SHA-256 hash verified"); };

  return <div className="app-shell"><aside className="sidebar"><div className="brand"><div className="brand-mark"><Shield size={17} /></div><div className="brand-copy"><div className="brand-name">SENTINEL</div><div className="brand-sub">Forensic command center</div></div></div><div className="nav-label">Workspace</div><nav className="nav">{navItems.map(({ label, icon: Icon, badge }) => <button key={label} className={`nav-btn ${active === label ? "active" : ""}`} onClick={() => navigate(label)}><Icon /><span>{label}</span>{badge && <span className="nav-badge">{badge}</span>}</button>)}</nav><div className="sidebar-spacer" /><div className="workspace-card"><div className="workspace-label">System health</div><div className="workspace-row"><span className="green-dot" />All systems operational</div><div className="workspace-row" style={{ marginTop: 8, color: "#7185a3", fontSize: 10 }}><Database size={12} />Snapshot synced 2 min ago</div></div><div className="profile"><div className="avatar">PS</div><div className="profile-copy"><div className="profile-name">Priya Sharma</div><div className="profile-role">Investigator · Demo workspace</div></div></div></aside><main className="main"><header className="topbar">{active !== "Overview" && <button className="back-btn" onClick={goBack}><ArrowLeft size={14} /> Back</button>}<div className="breadcrumb"><span className="breadcrumb-kicker">Workspace</span><ChevronRight size={13} color="#4c6487" /><span className="breadcrumb-title">{active === "Trace" ? "CASE-1042 / Trace" : active}</span></div><div className="search"><Search /><input placeholder="Search cases, wallets, hashes…" aria-label="Search cases, wallets, hashes" onKeyDown={event => { if (event.key === "Enter") { navigate("Cases"); notify(`Searching cases for “${event.currentTarget.value}”`); } }} /><kbd>⌘ K</kbd></div><div className="top-actions"><IconButton label="Open alerts" onClick={() => navigate("Watchdog")}><Bell /><span className="alert-dot" /></IconButton><IconButton label="Refresh data" onClick={() => notify("Data freshness verified · all sources current")}><RefreshCw /></IconButton><div className="user-chip"><div className="avatar" style={{ width: 27, height: 27 }}>PS</div><span>Priya</span></div></div></header><section className="content">{active === "Overview" && <Overview onOpenTrace={() => navigate("Trace")} onOpenWatchdog={() => navigate("Watchdog")} onOpenCases={() => navigate("Cases")} onToast={notify} />}{active === "Trace" && <TraceWorkspace onToast={notify} onOpenDossier={openDossier} />}{active === "Watchdog" && <Watchdog onToast={notify} />}{active === "Dossiers" && <Dossiers ready={dossierReady} onGenerate={generateDossier} onToast={notify} />}{active === "Cases" && <CasesView onOpenTrace={() => navigate("Trace")} onToast={notify} />}{active === "Settings" && <SettingsView onToast={notify} />}</section></main>{toast && <div className="toast"><Sparkles size={16} />{toast}</div>}</div>;
}
