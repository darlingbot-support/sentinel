import { describe, expect, it } from "vitest";
import { getScoreBand, isCompleteTrace, makeMovementDedupeKey, SCORE_VERSION, TRACE_SNAPSHOT_ID } from "../shared/sentinel";

describe("SENTINEL deterministic investigation rules", () => {
  it("keeps score bands explainable and bounded", () => {
    expect(getScoreBand(18)).toBe("exploratory");
    expect(getScoreBand(55)).toBe("review");
    expect(getScoreBand(78)).toBe("high_priority");
    expect(getScoreBand(94)).toBe("strongly_indicated");
    expect(SCORE_VERSION).toBe("rules-1.0");
  });

  it("creates stable, case-insensitive watchdog dedupe keys", () => {
    const first = makeMovementDedupeKey("ethereum", "0xABC123", "0xWallet");
    const second = makeMovementDedupeKey("ethereum", "0xabc123", "0xwallet");
    expect(first).toBe("ethereum:0xabc123:0xwallet");
    expect(second).toBe(first);
  });

  it("treats only complete jobs as ready for evidence export", () => {
    expect(isCompleteTrace("complete")).toBe(true);
    expect(isCompleteTrace("partial")).toBe(false);
    expect(isCompleteTrace("failed")).toBe(false);
    expect(TRACE_SNAPSHOT_ID).toContain("eth-seed");
  });
});
