export const TRACE_SNAPSHOT_ID = "eth-seed-2026.09.18";
export const SCORE_VERSION = "rules-1.0";

export type ScoreBand = "exploratory" | "review" | "high_priority" | "strongly_indicated";

export function getScoreBand(score: number): ScoreBand {
  if (score >= 86) return "strongly_indicated";
  if (score >= 70) return "high_priority";
  if (score >= 40) return "review";
  return "exploratory";
}

export function makeMovementDedupeKey(chain: string, txHash: string, monitoredAddress: string): string {
  return `${chain}:${txHash.toLowerCase()}:${monitoredAddress.toLowerCase()}`;
}

export function isCompleteTrace(status: "queued" | "running" | "complete" | "partial" | "failed"): boolean {
  return status === "complete";
}
